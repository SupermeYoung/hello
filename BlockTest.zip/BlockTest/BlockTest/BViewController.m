//
//  BViewController.m
//  BlockTest
//
//  Created by young on 2017/6/16.
//  Copyright © 2017年 young. All rights reserved.
//

#import "BViewController.h"

@interface BViewController ()
@property (nonatomic, retain)UITextField * textField;

@end

@implementation BViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor grayColor];
    [self initUI];
}
- (void)initUI{

    _textField = [[UITextField alloc]initWithFrame:CGRectMake(100, 100, 100, 40)];
    _textField.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:_textField];
   }
- (void)viewWillDisappear:(BOOL)animated{
    if (self.coloBlock){
    
        self.coloBlock(_textField.text);

    }
   }

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
