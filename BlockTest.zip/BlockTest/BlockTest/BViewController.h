//
//  BViewController.h
//  BlockTest
//
//  Created by young on 2017/6/16.
//  Copyright © 2017年 young. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^yyBlock)(NSString * str);
@interface BViewController : UIViewController

@property (nonatomic, copy) yyBlock coloBlock;
@end
