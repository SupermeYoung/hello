//
//  AViewController.m
//  BlockTest
//
//  Created by young on 2017/6/16.
//  Copyright © 2017年 young. All rights reserved.
//

#import "AViewController.h"
#import "BViewController.h"
@interface AViewController ()
@property (nonatomic, retain) UILabel * lable;
@property (nonatomic, retain) UIButton * btn;
@end

@implementation AViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor cyanColor];
    [self initUI];
}
- (void)initUI{

    _lable = [[UILabel alloc]initWithFrame:CGRectMake(100, 100, 100, 40)];
    _lable.backgroundColor = [UIColor whiteColor];
    _lable.textColor = [UIColor blackColor];
    [self.view addSubview:_lable];
    
    _btn = [[UIButton alloc]initWithFrame:CGRectMake(100, 200, 80, 40)];
    _btn.backgroundColor = [UIColor greenColor];
    [_btn setTitle:@"下一页" forState:UIControlStateNormal];
    [self.view addSubview:_btn];
    [_btn addTarget:self action:@selector(Click:) forControlEvents:UIControlEventTouchUpInside];
   }
- (void)Click:(UIButton *)sender{

    BViewController * bView = [[BViewController alloc]init];
//    __weak BViewController weakself = self;
    bView.coloBlock = ^(NSString * str) {
         _lable.text = str;
    };

    [self.navigationController pushViewController:bView animated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
